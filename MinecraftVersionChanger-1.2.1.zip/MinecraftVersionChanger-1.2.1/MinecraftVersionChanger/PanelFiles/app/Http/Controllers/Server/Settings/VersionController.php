<?php

namespace Pterodactyl\Http\Controllers\Server\Settings;

use Pterodactyl\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use GuzzleHttp\Exception\GuzzleException;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Validation\ValidationException;
use Pterodactyl\Repositories\Daemon\VersionRepository;
use Pterodactyl\Traits\Controllers\JavascriptInjection;
use Pterodactyl\Services\Servers\ReinstallServerService;
use Pterodactyl\Exceptions\Model\DataValidationException;
use Pterodactyl\Services\Servers\StartupModificationService;
use Pterodactyl\Exceptions\Repository\RecordNotFoundException;
use Pterodactyl\Exceptions\Http\Connection\DaemonConnectionException;

class VersionController extends Controller
{
    use JavascriptInjection;

    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    private $alert;

    /**
     * @var \Pterodactyl\Repositories\Daemon\VersionRepository
     */
    protected $versionRepository;

    /**
     * @var \Pterodactyl\Services\Servers\ReinstallServerService
     */
    protected $reinstallServerService;

    /**
     * @var \Pterodactyl\Services\Servers\StartupModificationService
     */
    protected $startupModificationService;

    /**
     * VersionController constructor.
     * @param AlertsMessageBag $alert
     * @param VersionRepository $versionRepository
     * @param ReinstallServerService $reinstallServerService
     * @param StartupModificationService $startupModificationService
     */
    public function __construct(AlertsMessageBag $alert, VersionRepository $versionRepository, ReinstallServerService $reinstallServerService, StartupModificationService $startupModificationService)
    {
        $this->alert = $alert;
        $this->versionRepository = $versionRepository;
        $this->reinstallServerService = $reinstallServerService;
        $this->startupModificationService = $startupModificationService;
    }

    /**
     * @param Request $request
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function index(Request $request)
    {
        $server = $request->attributes->get('server');
        $this->authorize('view-versions', $server);
        $this->setRequest($request)->injectJavascript();

        $versions = [];
        $groups = DB::table('version_groups')->orderBy('sort', 'ASC')->get();
        foreach ($groups as $group) {
            if (in_array($server->egg_id, unserialize($group->eggs))) {
                if ($group->type == 1) {
                    $group->versions = [];
                    $versions_from_db = DB::table('versions')->where('group_id', '=', $group->id)->orderBy('sort', 'ASC')->get();

                    foreach ($versions_from_db as $version_from_db) {
                        $version_from_db->method = 'database';
                        $version_from_db->current_check = $version_from_db->id;

                        array_push($group->versions, $version_from_db);
                    }
                }

                if (in_array($group->type, [2, 3])) {
                    try {
                        $directory_scan = $this->versionRepository->setServer($server)->get([
                            'folder' => $group->folder,
                        ]);
                    } catch (GuzzleException $e) {
                        $group->versions = [];
                        continue;
                    }

                    if (json_decode($directory_scan->getBody())->success != 'true') {
                        $group->version = [];
                        continue;
                    }

                    if ($group->type == 2) {
                        $group->versions = [];
                        $loaded_versions = json_decode($directory_scan->getBody())->versions;

                        foreach ($loaded_versions as $loaded_version) {
                            array_push($group->versions, (object) [
                                'method' => 'file',
                                'current_check' => $loaded_version,
                                'name' => str_replace('.jar', '', $loaded_version),
                                'file' => $loaded_version,
                            ]);
                        }
                    } else {
                        $group->versions = [];
                        $loaded_versions = json_decode($directory_scan->getBody())->versions;

                        foreach ($loaded_versions as $loaded_version) {
                            $loaded_version = DB::table('versions')->where('group_id', '=', $group->id)->where('download_url', '=', $loaded_version)->get();
                            if (count($loaded_version) > 0) {
                                $loaded_version[0]->method = 'database';
                                $loaded_version[0]->current_check = $loaded_version[0]->id;

                                array_push($group->versions, $loaded_version[0]);
                            }
                        }
                    }
                }

                if ($group->type == 4) {
                    $group->versions = [];
                    foreach (unserialize($group->eggs) as $egg) {
                        $egg = DB::table('eggs')->select(['id', 'name'])->where('id', '=', $egg)->get();
                        $egg[0]->method = 'egg';
                        $egg[0]->current_check = $egg[0]->id;

                        array_push($group->versions, $egg[0]);
                    }
                }

                array_push($versions, $group);
            }
        }

        $currect_version = [
            'method' => 'none',
            'key' => 0
        ];

        if (!is_null($server->version)) {
            $currect_version = unserialize($server->version);
        }

        return view('server.settings.version', [
            'current_version' => $currect_version,
            'groups' => $versions,
        ]);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function switch(Request $request)
    {
        $server = $request->attributes->get('server');
        $this->authorize('view-versions', $server);

        try {
            $this->validate($request, [
                'group' => 'required|integer',
                'method' => 'required',
                'key' => 'required',
                'delete_files' => 'required|integer'
            ]);
        } catch (ValidationException $e) {
            $this->alert->danger('Invalid version data. Please try again...')->flash();

            return redirect()->route('server.settings.version', $server->uuidShort);
        }

        $group = (int) $request->input('group');
        $method = trim(strip_tags($request->input('method')));
        $key = trim($request->input('key'));
        $delete_files = (int) $request->input('delete_files');

        if (!in_array($method, ['file', 'database', 'egg'])) {
            $this->alert->danger('Invalid version type. Please try again...')->flash();

            return redirect()->route('server.settings.version', $server->uuidShort);
        }

        if ($method == 'file') {
            $group = DB::table('version_groups')->where('id', '=', $group)->get();
            if (count($group) < 1) {
                $this->alert->danger('Version group not found. Please try again...')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }

            $available = false;
            foreach (unserialize($group[0]->eggs) as $item) {
                if ($item == $server->egg_id) {
                    $available = true;
                }
            }

            if (!$available) {
                $this->alert->danger('You can\'t use selected version. Please try again...')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }

            try {
                $switch = $this->versionRepository->setServer($server)->switch([
                    'method' => $method,
                    'folder' => $group[0]->folder,
                    'version' => $key,
                    'filename' => '',
                    'action' => 'none',
                    'delete_files' => $delete_files + 1,
                ]);
            } catch (GuzzleException $e) {
                $this->alert->danger('Failed to change the server version.')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }

            if (json_decode($switch->getBody())->success != "true") {
                $this->alert->danger('Failed to change the server version.')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }
        }

        if ($method == 'database') {
            $group = DB::table('version_groups')->where('id', '=', $group)->get();
            if (count($group) < 1) {
                $this->alert->danger('Version group not found. Please try again...')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }

            $version = DB::table('versions')->where('id', '=', (int) $key)->where('group_id', '=', $group[0]->id)->get();
            if (count($version) < 1) {
                $this->alert->danger('Version not found. Please try again...')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }

            $available = false;
            foreach (unserialize($group[0]->eggs) as $item) {
                if ($item == $server->egg_id) {
                    $available = true;
                }
            }

            if (!$available) {
                $this->alert->danger('You can\'t use selected version. Please try again...')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }

            try {
                $switch = $this->versionRepository->setServer($server)->switch([
                    'method' => $group[0]->type == 1 ? 'download' : 'file',
                    'folder' => $group[0]->folder,
                    'version' => $version[0]->download_url,
                    'filename' => $version[0]->filename,
                    'action' => $version[0]->action == 2 ? 'unzip' : 'none',
                    'delete_files' => $delete_files + 1,
                ]);
            } catch (GuzzleException $e) {
                $this->alert->danger('Failed to change the server version.')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }

            if (json_decode($switch->getBody())->success != "true") {
                $this->alert->danger('Failed to change the server version.')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }
        }

        if ($method == 'egg') {
            $egg = DB::table('eggs')->where('nest_id', '=', 1)->where('id', '=', (int) $key)->get();
            if (count($egg) < 1) {
                $this->alert->danger('Version not found. Please try again...')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }

            $available = false;
            $version = DB::table('version_groups')->where('type', '=', 4)->where('id', '=', $group)->get();
            if (count($version) < 1) {
                $this->alert->danger('Version group not found. Please try again...')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }

            foreach (unserialize($version[0]->eggs) as $item) {
                if ($item == $egg[0]->id) {
                    $available = true;
                }
            }

            if (!$available) {
                $this->alert->danger('You can\'t use selected version. Please try again...')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }

            $this->startupModificationService->setUserLevel(User::USER_LEVEL_ADMIN);
            try {
                $this->startupModificationService->handle($server, [
                    'nest_id' => $egg[0]->nest_id,
                    'egg_id' => $egg[0]->id,
                    'docker_image' => $egg[0]->docker_image,
                ]);
            } catch (ValidationException $e) {
                $error = $e->getMessage();
            } catch (DaemonConnectionException $e) {
                $error = $e->getMessage();
            } catch (DataValidationException $e) {
                $error = $e->getMessage();
            } catch (RecordNotFoundException $e) {
                $error = $e->getMessage();
            }

            if (isset($error)) {
                $this->alert->danger('Failed to change the server version. Please try again...')->flash();

                return redirect()->route('server.settings.version', $server->uuidShort);
            }

            if ($delete_files == 1) {
                try {
                    $this->reinstallServerService->reinstall($server);
                } catch (DisplayException $e) {
                    $error = $e->getMessage();
                } catch (DataValidationException $e) {
                    $error = $e->getMessage();
                } catch (RecordNotFoundException $e) {
                    $error = $e->getMessage();
                }

                if (isset($error)) {
                    $this->alert->danger('Failed to delete server files. Please reinstall it manually.')->flash();

                    return redirect()->route('server.settings.version', $server->uuidShort);
                }
            }
        }

        $currect_version = [
            'method' => $method,
            'key' => $key
        ];

        DB::table('servers')->where('id', '=', $server->id)->update([
            'version' => serialize($currect_version)
        ]);

        $this->alert->success('Successful version change! Please restart your server...')->flash();

        return redirect()->route('server.settings.version', $server->uuidShort);
    }
}
