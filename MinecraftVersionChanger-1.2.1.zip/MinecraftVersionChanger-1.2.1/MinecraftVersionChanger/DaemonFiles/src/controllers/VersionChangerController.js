const Fs = require('fs-extra');
const {exec} = require('child_process');
const DecompressZip = require('decompress-zip');
const Request = require('request');

const ConfigHelper = require('./../helpers/config');
const ResponseHelper = require('./../helpers/responses');

const Config = new ConfigHelper();

class MinecraftPluginInstallerController {
    constructor(auth, req, res) {
        this.req = req;
        this.res = res;

        this.auth = auth;
        this.responses = new ResponseHelper(req, res);
    }

    getVersions() {
        this.auth.allowed('s:version', (allowedErr, isAllowed) => {
            if (allowedErr || !isAllowed) return;

			if ("folder" in this.req.params === false)
                return this.res.send({"success": "false", "error": "Missing folder argument"});

            const folder = this.req.params["folder"];

            let files = [];

            Fs.readdirSync(folder).forEach(file => {
                files.push(file);
            });

            this.res.send({"success": "true", "versions": files});
        });
    }

    deleteFiles(delete_files, uuid, auth, next) {
        if (parseInt(delete_files) === 2) {
            exec(`rm -rf ${Config.get('sftp.path').toString()}/${uuid}/*`, (err, stdout, stderr) => {
                if (err) {
                    return next(err);
                }

                return next();
            });
        } else {
            exec(`rm -f ${Config.get('sftp.path').toString()}/${uuid}/*.jar`, (err, stdout, stderr) => {
                if (err) {
                    return next(err);
                }

                return next();
            });
        }
    }

    switchVersion() {
        this.auth.allowed('s:version', (allowedErr, isAllowed) => {
            if (allowedErr || !isAllowed) return;

            if ("method" in this.req.params === false)
                return this.res.send({"success": "false", "error": "Missing method argument"});
            if ("folder" in this.req.params === false)
                return this.res.send({"success": "false", "error": "Missing folder argument"});
            if ("version" in this.req.params === false)
                return this.res.send({"success": "false", "error": "Missing version argument"});
            if ("filename" in this.req.params === false)
                return this.res.send({"success": "false", "error": "Missing filename argument"});
            if ("action" in this.req.params === false)
                return this.res.send({"success": "false", "error": "Missing action argument"});
            if ("delete_files" in this.req.params === false)
                return this.res.send({"success": "false", "error": "Missing delete files argument"});

            const method = this.req.params["method"];
            const folder = this.req.params["folder"];
            let version = this.req.params["version"];
            let filename = this.req.params["filename"];
            const action = this.req.params["action"];
            const delete_files = this.req.params["delete_files"];

            const res = this.res;
            const auth = this.auth;
            const uuid = this.auth.server().uuid;

            this.deleteFiles(delete_files, uuid, auth, (err) => {
                if (err) {
                    return res.send({
                        "success": "false",
                        "error": "Failed to delete old server files / old server version."
                    });
                }

                if (method === 'download') {
                    if (action === 'unzip') {
                        filename = 'version.zip';
                    }

                    Request({
                        method: 'GET',
                        url: version,
                        followAllRedirects: true,
                        headers: {
                            'Connection': 'keep-alive',
                            'User-Agent': 'minecraft-version-changer/1.2'
                        },
                    }).on('response', (response) => {
                        const file = Fs.createWriteStream(`${Config.get('sftp.path').toString()}/${uuid}/${filename}`);

                        response.pipe(file);

                        response.on('end', () => {
                            auth.server().fs.chown(`/${filename}`, (err) => {
                                if (action === 'unzip') {
                                    let unzipperList = new DecompressZip(`${Config.get('sftp.path').toString()}/${uuid}/${filename}`);

                                    unzipperList.on('error', (err) => {
                                        console.log('Failed to unzip ' + filename + ' plugin in ' + uuid);
                                        console.log(err);
                                    });

                                    unzipperList.on('list', (files) => {
                                        let unzipper = new DecompressZip(`${Config.get('sftp.path').toString()}/${uuid}/${filename}`);

                                        unzipper.on('error', (err) => {
                                            auth.server().fs.rm(`/version.zip`, (err) => {
                                            });

                                            return res.send({"success": "false", "error": "Failed to download the server version."});
                                        });

                                        unzipper.on('extract', (log) => {
                                            files.forEach((item) => {
                                                auth.server().fs.chown(`/${item}`, (err) => {
                                                });
                                            });

                                            auth.server().fs.rm('/version.zip', (err) => {
                                                return res.send({"success": "true"});
                                            });
                                        });

                                        unzipper.extract({
                                            path: `${Config.get('sftp.path').toString()}/${uuid}/`,
                                            filter: function (file) {
                                                return file.type !== "SymbolicLink";
                                            }
                                        });
                                    });

                                    unzipperList.list();
                                } else {
                                    return res.send({"success": "true"});
                                }
                            });
                        });
                    }).on('error', (err) => {
                        auth.server().fs.rm(`/${filename}`, (err) => {
                        });

                        return res.send({"success": "false", "error": "Failed to download the server version."});
                    });
                }

                if (method === 'file') {
                    Fs.access(`${folder}/${version}`, (err) => {
                        if (err) {
                            return res.send({"success": "false", "error": "Version not found in the daemon server."});
                        }

                        if (filename === '') {
                            filename = version;
                        }

                        exec(`cp ${folder}/${version} ${Config.get('sftp.path').toString()}/${uuid}/${filename}`, (err, stdout, stderr) => {
                            if (err) {
                                return res.send({
                                    "success": "false",
                                    "error": "Failed to copy the version to the server directory."
                                });
                            }

                            this.auth.server().fs.chown(`/${filename}`, (err) => {
                                return res.send({"success": "true"});
                            });
                        });
                    })
                }
            });
        });
    }
}

module.exports = MinecraftPluginInstallerController;
